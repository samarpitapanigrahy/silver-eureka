# Online Tiffin Service Mangement System Using Django

Online Tiffin Service System is a Django based web application which strives to make an online portal for both vendors and customers. Using Interactive GUI anyone can quickly learn to use the complete system. This system will give power and flexibility to the administrator to manage the entire system from a single online portal.

In Online Tiffin Service System we use Python Django and SQLite Database. This project keeps the records of Tiffin’s orders. This project has three modules i.e. admin, vendor and customers.

Running the File:

To run the file use the command:
python manage.py runserver


Admin eamil - admin@admin.com

admin username - admin

admin -admin123

Vendor ID

11910617
11910616
11910615


If your system doesn't have django installed. Please refer this link: https://docs.djangoproject.com/en/4.0/howto/windows/





